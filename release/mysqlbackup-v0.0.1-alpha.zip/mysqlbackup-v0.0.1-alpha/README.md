This is the alpha, pre-release version of this project. 

Copy it to your PATH for ease of use.

`sudo mv mysqlbackup /usr/bin/`

I gradually developed it until I added four (4) backup methods: SCP (Secure Copy), Copy, S3 and Email.

Set the environment variable **MYSQL_BACKUP_ENV** if you would like to name the archive differently. This is good for if you have this script running on multiple servers and pushing to the same backup location.

`export MYSQL_BACKUP_ENV=development`

You may or may not use a MySQL defaults file but I recommend using one.

Run the below commands to see the version or get help respectively.

`mysqlbackup version`

`mysqlbackup help`

If you simply want to execute a backup, either run the script in the same directory as the configuration file, conf.ini, if you have not copied it to your PATH, or pass it the path of the configuration file. Eg:

`mysqlbackup /home/ramone/mysqlbackup.ini`

This project was ONLY tested on **Ubuntu 22.04.4 LTS**. Use it at your own risk.

I hope this project makes someone's life easier by helping them to automate MySQL backups securely.
